# 5. Class Diagram 
